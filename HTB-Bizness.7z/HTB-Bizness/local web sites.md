Using a pivot tool such as chisel with a user account on the box, you can access other ports on the machine (that are available locally only):

[[8080]]
[[8009]]
[[8443]]

Nginx is running as root serving port 8443.
Port ___ is configured to fwd to port 8443.
ASSUMPTION: Since nginx is proxying all these, exploiting them won't give us root. For that, you'd have to exploit nginx itself.


## configuring chisel

on local box: 
```
./chisel server -p 9000 --reverse 
```

on bizness.htb: 
```
./chisel client 10.10.14.134:9000 R:socks 
```

Set browser to do a sock5 proxy over 1080 go to 127.0.0.1:8080 to see local site.

