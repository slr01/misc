With a user account, you can run LinPEAS to find priv esc.

