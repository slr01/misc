---
cssclasses:
  - killchain
---
[[4-PERSISTENCE]]

