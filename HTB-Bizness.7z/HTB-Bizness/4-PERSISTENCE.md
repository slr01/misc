---
cssclasses:
  - killchain
---
[[5-ENUMERATION]]

## Shell improvement

```
python3 -c 'import pty;pty.spawn("/bin/bash")'
```

Then hit CTRL-Z.

stty raw -echo; fg

...then ENTER twice

export TERM=xterm

stty rows 32 columns 131


CTRL-L to test the shell - did ti clear the screen?
If so, CTRL-C won't kill your shell.


---

## Install Public Key

Copy your public key into /home/ofbiz/.ssh/authorized_keys
... to allow easy ssh, scp, etc.
