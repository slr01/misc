---
tags: 
cssclasses:
  - path
---
This password is the root password due to password reuse.

[[7-ROOT]]

```
su root
```

