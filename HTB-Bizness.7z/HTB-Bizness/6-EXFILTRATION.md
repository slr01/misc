---
cssclasses:
  - killchain
tags:
---
[[Derby DB]]

(download the Derby DB)



Local box:
```
sudo apt install derby-tools
```

Zip and transmit the Derby database files to your local box:

```
cd /opt/ofbiz/runtime/data/derby
tar -czf ~/derby.tar.gz ofbiz
```

